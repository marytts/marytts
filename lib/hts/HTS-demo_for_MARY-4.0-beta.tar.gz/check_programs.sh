# HMMVoice creation for MARY 4.0 beta
#
  echo "check_programs.sh: check the necessary programs (and versions) to run the HTS-HTK demo for MARY 4.0 beta"
  echo "Usage: $0 [path-to-awk|path-to-perl|path-to-tclsh|path-to-bc|path-to-sox|path-to-htk|path-to-htsengine|path-to-sptk]"
  echo

# Add the paths provided to the general $PATH
for p in $@ 
do
  PATH=$p:$PATH
done


echo "The following programs will be checked:"
echo "awk, perl, tclsh and snack, bc, sox, htk, hts_engine, sptk, ehmm (festvox)"
echo "The programs will be search in the PATH and the directories provided as parameters"
echo "If a program is not found, it will be suggested how to install it."
echo ""
echo


#################awk
echo "________________________________________________________________"
if which awk > /dev/null; then
   awkProg=`which awk`
   awkPath=`dirname $awkProg`
   echo "awk: $awkProg"
   echo "ok"
   echo
else
   echo "awk: was not found"
   awkPath="missing"
   echo "It can be installed with: sudo apt-get install awk"
   echo
fi

################## perl
echo "________________________________________________________________"
if which perl > /dev/null; then
   perlProg=`which perl`
   perlPath=`dirname $perlProg`
   echo "perl: $perlProg"
   echo "ok"
   echo
else
   echo "perl: was not found"
   perlPath="missing"
   echo "It can be installed with: sudo apt-get install perl"
   echo
fi


################# tclsh and snack
echo "________________________________________________________________"
if which tclsh > /dev/null; then
    tclshProg=`which tclsh`
    tclshPath=`dirname $tclshProg`
    echo "tclsh: $tclshProg"
    echo "package require snack" > tmp.tcl
    echo "snack::sound s" >> tmp.tcl
    if `$tclshProg tmp.tcl` > /dev/null; then
       rm tmp.tcl
       echo "tclsh and snack exist"
       echo "ok"
       echo
    else
      tclshPath="installed but it does not support snack"
      dirTcl=`dirname $tclshProg`
      dirTcl=`dirname $dirTcl`
      echo "tclsh installed but it does not support snack." 
      echo "snack can be downloaded from: http://www.speech.kth.se/snack/dist/snack2.2.10-linux.tar.gz"
      echo "unpack it and then copy the directory to your $dirTcl/lib directory"
      echo "suggested commands:"
      echo "  wget http://www.speech.kth.se/snack/dist/snack2.2.10-linux.tar.gz"
      echo "  tar -zxvf snack2.2.10-linux.tar.gz"      
      echo "  cp -r snack2.2.10 $dirTcl/lib/"
      echo
    fi
else
    tclshPath="missing"
    echo "tclsh: was not found"
    echo "It can be installed with the command:"
    echo "  sudo apt-get install tclsh"
    echo "Alternatively: it can be downloaded from: http://www.activestate.com/Products/ActiveTcl/ "
    echo "follow the installation instructions."
    echo
fi



################## bc
echo "________________________________________________________________"
if which bc > /dev/null; then
   bcProg=`which bc`
   bcPath=`dirname $bcProg`
   echo "bc: $bcProg" 
   # also check the math lib
   count=`echo "0.005 * 1600" | bc -l`
   echo "bc: checking -l (mathlib)"
   if [ $count = 8.000 ]; then     
     echo "ok"
     echo
   else
     bcPath="installed but missing mathlib"
     echo "Missing mathlib for running bc, install a newer version of bc"
     echo "It can be installed with the command:"
     echo "  sudo apt-get install bc"
     echo
   fi 
else
   bcPath="missing"
   echo "bc: was not found"
   echo "It can be installed with the command:"
   echo "  sudo apt-get install bc"
   echo
fi


################ sox
echo "________________________________________________________________"
if which sox > /dev/null; then
    soxProg=`which sox`
    soxPath=`dirname $soxProg`
    # check sox version
    soxVer=`sox --version | awk '{print substr($3,2,2)}'`
    if [ $soxVer -ge 13 ]; then
      echo "sox: $soxProg"
      echo "ok"
      echo
    else
      soxPath="old version: $soxVer require >= v13"
      echo "sox: $soxProg"
      echo "sox installed but is an old version ($soxVer), please install sox >= v13"
      echo "It can be installed with the command:"
      echo "  sudo apt-get install sox"
      echo "Alternatively: it can be downloaded from: http://sox.sourceforge.net/ "
      echo "follow the installation instructions."
      echo
    fi
else
    soxPath="missing"
    echo "sox: was not found"
    echo "It can be installed with the command:"
    echo "  sudo apt-get install sox"
    echo "Alternatively: it can be downloaded from: http://sox.sourceforge.net/ "
    echo "follow the installation instructions."
    echo
fi


################# HTK
echo "________________________________________________________________"
if which HHEd > /dev/null; then
    echo "HTK HHEd exists"
    hhedProg=`which HHEd`
    htkPath=`dirname $hhedProg`
    # Check HTK version and if it is patched with HTS
    htkVer=`$hhedProg -V | grep HHEd | awk '{print $2}'`
    echo "HTK version: $htkVer" 
    # Check if htk is patched, if so HHEd has to have a CM command which is:
    # CM directory         - Convert models to pdf for speech synthesizer
    htsCommands=`$hhedProg -Q | grep CM | awk '{print $1}' `
    if [ $htsCommands == "CM" ]; then      
       echo "HTK HHED contains HTS commands like CM "
       echo "HTK patched with HTS ok"
       echo
    else
       htkPath="installed but without HTS path"
       echo "htk installed but it seems not patched with HTS, HHEd does not have command CM."
       echo "it can be downloaded from: http://hts.sp.nitech.ac.jp/archives/2.1/HTS-2.1_for_HTK-3.4.tar.bz2"
       echo "suggested commands:"
       echo "  mkdir HTS-patch"
       echo "  cd HTS-patch"
       echo "  tar -jxvf HTS-2.1_for_HTK-3.4.tar.bz2"
       echo "move HTS-2.1_for_HTK-3.4.tar.bz2 to your htk directory and there execute:"
       echo "  patch -p1 -d . < HTS-2.1_for_HTK-3.4.patch"
       echo "then run configure with something like (you might provide a --prefix directory as well):"
       echo "  ./configure MAXSTRLEN=2048"
       echo "and then follow the instructions for compiling and installing."
       echo
    fi
else
    htkPath="missing"
    echo "HTK 3.4: was not found"
    echo "it can be downloaded from: http://htk.eng.cam.ac.uk/download.shtml "
    echo "follow the installation instructions."
    echo "When compiling htk it is recommended to set the configuration variable MAXTRLEN :"
    echo "command:"
    echo "  ./configure MAXSTRLEN=2048"
    echo "   (This will allow to use long context feature vectors)"
    echo
fi


################# hts_engine
echo "________________________________________________________________"
if which hts_engine > /dev/null; then
    echo "hts_engine exists"
    hts_engineProg=`which hts_engine`
    hts_enginePath=`dirname $hts_engineProg`
    echo "hts_engine: $hts_engineProg" 
    echo "ok"
    echo
else
    hts_enginePath="missing"
    echo "hts_engine: was not found"
    echo "it can be downloaded from: http://downloads.sourceforge.net/hts-engine/hts_engine_API-1.01.tar.gz "
    echo "suggested commands:"
    echo "  wget http://downloads.sourceforge.net/hts-engine/hts_engine_API-1.01.tar.gz"
    echo "  tar -zxvf hts_engine_API-1.01.tar.gz"
    echo "follow the instructions for compiling and installing."
    echo
fi


################# SPTK
echo "________________________________________________________________"
if which mgcep > /dev/null; then
    echo "SPTK exists"
    mgcepProg=`which mgcep`
    sptkPath=`dirname $mgcepProg`
    echo "SPTK path: $sptkPath" 
    #check SPTK version
    # we need SPTK 3.2 which support gmm (check if gmm exist)
    if which gmm > /dev/null; then
      echo "SPTK version >= 3.2" 
      echo "ok"
      echo
    else
      sptkPath="old version < 3.2"
      echo "SPTK gmm does not exist, SPTK version < 3.2" 
      echo "SPTK installed but probably an older version, please install SPTK 3.2"
      echo "it can be downloaded from: http://downloads.sourceforge.net/sp-tk/SPTK-3.2.tar.gz "
      echo "suggested commands:"
      echo "  wget http://downloads.sourceforge.net/sp-tk/SPTK-3.2.tar.gz"
      echo "  tar -zxvf SPTK-3.2.tar.gz"
      echo "follow the instructions for compiling and installing."
      echo
    fi
else
    sptkPath="missing"
    echo "SPTK: was not found"
    echo "it can be downloaded from: http://downloads.sourceforge.net/sp-tk/SPTK-3.2.tar.gz "
    echo "suggested commands:"
    echo "  wget http://downloads.sourceforge.net/sp-tk/SPTK-3.2.tar.gz"
    echo "  tar -zxvf SPTK-3.2.tar.gz"
    echo "follow the instructions for compiling and installing."
    echo
fi


################# ehmm from Festival
echo "________________________________________________________________"
if which ehmm > /dev/null; then
    echo "festvox ehmm exists"
    ehmmProg=`which ehmm`
    ehmmPath=`dirname $ehmmProg`
    echo "festvox path: $ehmmPath" 
    echo "ehmm exist"
    echo "ok"
else
    ehmmPath="missing"
    echo "ehmm: was not found"
    echo "so probably festvox is not installed or provide a path for that,"
    echo "normally it can be found in your Festival directory:"
    echo "   ../Festival/festvox/src/ehmm/bin "
    echo "it can be downloaded from: http://festvox.org/festvox-2.1/festvox-2.1-release.tar.gz "
    echo "suggested commands:"
    echo "  wget http://festvox.org/festvox-2.1/festvox-2.1-release.tar.gz"
    echo "  tar -zxvf festvox-2.1-release.tar.gz"
    echo "follow the instructions for compiling and installing."
    echo
fi


############ paths
echo "________________________________________________________________"
echo "Programs status (detailed information above):"
echo "The following paths should be in the PATH variable"
echo "  awk: $awkPath"
echo "  perl: $perlPath"
echo "  bc: $bcPath"
echo
echo "The following paths are used when running HMMVoiceConfigure"
echo "  tclsh: $tclshPath"
echo "  sox: $soxPath"
echo "  htk: $htkPath"
echo "  hts_engine: $hts_enginePath"
echo "  sptk: $sptkPath"
echo
echo "This path is used when running the EHMMlabeler"  
echo "  ehmm: $ehmmPath"
echo